package Controlcustomer;

public class cart {	
	
		private int cid;
		private String bookName;
		private Double price;
		private Double totalprice;
		
		
		public int getCid() {
			return cid;
		}
		public void setCid(int cid) {
			this.cid = cid;
		}
		public String getBookName() {
			return bookName;
		}
		public void setBookName(String bookName) {
			this.bookName = bookName;
		}
		public Double getPrice() {
			return price;
		}
		public void setPrice(Double price) {
			this.price = price;
		}
		public Double getTotalprice() {
			return totalprice;
		}
		public void setTotalprice(Double totalprice) {
			this.totalprice = totalprice;
		}
		
		
		
		
		
}
